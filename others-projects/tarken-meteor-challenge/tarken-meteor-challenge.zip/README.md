# Resposta do desafio *Meteor Challenge*

| Cases                        | Count |
|------------------------------|-------|
| Number of Stars              | 315   |
| Number of Meteors            | 328   |
| Meteors falling on the Water | 105   |
